package kim.chopper.bookstore.book;
//자바빈(bean) 클래스
public class BookVO {
	//필드 = 멤버변수
	private int bookId;
	private String bookName;
	private String publisher;
	private int price;
	
	//기본생성자
	public BookVO() {
	}

	//getter/setter메서드
	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return String.format("BookVO [bookId=%s, bookName=%s, publisher=%s, price=%s]", bookId, bookName, publisher,
				price);
	}
	
	
	
}
