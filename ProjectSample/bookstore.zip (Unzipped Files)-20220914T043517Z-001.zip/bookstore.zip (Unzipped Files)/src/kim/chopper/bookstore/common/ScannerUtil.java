package kim.chopper.bookstore.common;

import java.util.Scanner;

public class ScannerUtil {
    private static Scanner scanner = new Scanner(System.in);

    public static Scanner scanner() {
        return scanner;
    }
}
