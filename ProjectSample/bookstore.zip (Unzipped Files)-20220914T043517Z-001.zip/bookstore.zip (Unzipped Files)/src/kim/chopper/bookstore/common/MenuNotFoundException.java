package kim.chopper.bookstore.common;

public class MenuNotFoundException extends Exception {
    public MenuNotFoundException(String message) {
        super(message);
    }
}
